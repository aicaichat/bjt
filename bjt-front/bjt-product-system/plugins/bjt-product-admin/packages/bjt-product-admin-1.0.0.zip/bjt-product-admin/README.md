# BJT Product Management System

A WordPress plugin for managing product lines, products, features, and specifications with multi-language support.

## Features

- Product Line Management
- Product Management
- Feature Management with Images
- Technical Specifications
- Multi-language Support (English/Chinese)
- Media Library Integration
- Drag-and-Drop Sorting
- Responsive Admin Interface

## Installation

1. Download the plugin zip file
2. Go to WordPress admin panel > Plugins > Add New
3. Click "Upload Plugin" and select the downloaded zip file
4. Click "Install Now" and then "Activate"

## Usage

### Product Lines

1. Go to WordPress admin panel > BJT Products > Product Lines
2. Click "Add New" to create a product line
3. Fill in the product line details:
   - Title (English/Chinese)
   - Description (English/Chinese)
   - Status
   - Sort Order

### Products

1. Go to WordPress admin panel > BJT Products > Products
2. Click "Add New" to create a product
3. Fill in the product details:
   - Title (English/Chinese)
   - Product Code
   - Product Line
   - Status
   - Sort Order
   - Features
   - Specifications

### Features

1. When editing a product, use the "Product Features" meta box
2. Click "Add Feature" to add a new feature
3. Fill in the feature details:
   - Title (English/Chinese)
   - Description (English/Chinese)
   - Image (optional)
4. Drag and drop to reorder features

### Specifications

1. When editing a product, use the "Product Specifications" meta box
2. Click "Add Specification" to add a new specification
3. Fill in the specification details:
   - Name (English/Chinese)
   - Value (English/Chinese)
4. Drag and drop to reorder specifications

### Media Management

1. Go to WordPress admin panel > BJT Products > Media Library
2. Upload and manage product images
3. Images can be used in product features and product details

## Requirements

- WordPress 5.0 or higher
- PHP 7.2 or higher
- MySQL 5.6 or higher

## Development

### File Structure

```
bjt-product-admin/
├── assets/
│   ├── css/
│   │   └── admin-styles.css
│   └── js/
│       └── product-admin.js
├── includes/
│   └── admin/
│       ├── admin-menu.php
│       ├── dashboard.php
│       └── product-management.php
├── languages/
├── bjt-product-admin.php
└── README.md
```

### Adding New Features

1. Create new files in the appropriate directories
2. Include new files in the main plugin file
3. Add necessary hooks and functions
4. Update the admin interface as needed

### Customization

The plugin can be customized by:

1. Modifying CSS in `admin-styles.css`
2. Adding JavaScript functionality in `product-admin.js`
3. Extending PHP functions in the plugin files
4. Using WordPress filters and actions

## Support

For support, please contact the development team or create an issue in the repository.

## License

This plugin is proprietary software. All rights reserved.

## Changelog

### 1.0.0
- Initial release
- Basic product management functionality
- Multi-language support
- Media management
- Feature and specification management 