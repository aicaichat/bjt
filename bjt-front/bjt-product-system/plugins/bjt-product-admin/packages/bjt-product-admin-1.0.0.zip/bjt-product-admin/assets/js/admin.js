jQuery(document).ready(function($) {
    // Language tab switching
    $('.language-tab').on('click', function() {
        const tabId = $(this).data('tab');
        $('.language-tab').removeClass('active');
        $('.language-content').removeClass('active');
        $(this).addClass('active');
        $(`#${tabId}`).addClass('active');
    });

    // Image upload handling
    const imageUploadArea = $('.image-upload-area');
    const fileInput = $('#image-upload');
    const imagePreview = $('#image-preview');
    const removeImageBtn = $('#remove-image');

    // Drag and drop events
    imageUploadArea.on('dragover', function(e) {
        e.preventDefault();
        $(this).addClass('drag-over');
    });

    imageUploadArea.on('dragleave', function(e) {
        e.preventDefault();
        $(this).removeClass('drag-over');
    });

    imageUploadArea.on('drop', function(e) {
        e.preventDefault();
        $(this).removeClass('drag-over');
        const files = e.originalEvent.dataTransfer.files;
        handleFiles(files);
    });

    // File input change
    fileInput.on('change', function() {
        handleFiles(this.files);
    });

    // Remove image
    removeImageBtn.on('click', function() {
        imagePreview.attr('src', '').hide();
        fileInput.val('');
        $(this).hide();
        imageUploadArea.show();
    });

    function handleFiles(files) {
        if (files.length > 0) {
            const file = files[0];
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.attr('src', e.target.result).show();
                    imageUploadArea.hide();
                    removeImageBtn.show();
                };
                reader.readAsDataURL(file);
            } else {
                showToast('请选择图片文件', 'error');
            }
        }
    }

    // Form validation and submission
    $('#product-line-form').on('submit', function(e) {
        e.preventDefault();
        
        // Validate required fields
        let isValid = true;
        $('.language-content.active input[required], .language-content.active textarea[required]').each(function() {
            if (!$(this).val().trim()) {
                isValid = false;
                $(this).addClass('error');
            } else {
                $(this).removeClass('error');
            }
        });

        if (!isValid) {
            showToast('请填写所有必填字段', 'error');
            return;
        }

        // Prepare form data
        const formData = new FormData(this);
        formData.append('action', 'save_product_line');
        formData.append('nonce', bjtProductAdmin.nonce);

        // Show progress bar
        const progressContainer = $('.progress-container');
        const progressBar = $('.progress-bar');
        progressContainer.show();
        progressBar.css('width', '0%');

        // Submit form
        $.ajax({
            url: bjtProductAdmin.ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                const xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percent = Math.round((e.loaded / e.total) * 100);
                        progressBar.css('width', percent + '%');
                    }
                }, false);
                return xhr;
            },
            success: function(response) {
                if (response.success) {
                    showToast('保存成功', 'success');
                    setTimeout(function() {
                        window.location.reload();
                    }, 1500);
                } else {
                    showToast(response.data.message || '保存失败', 'error');
                }
            },
            error: function() {
                showToast('服务器错误，请稍后重试', 'error');
            },
            complete: function() {
                progressContainer.hide();
                progressBar.css('width', '0%');
            }
        });
    });

    // Toast notification
    function showToast(message, type = 'success') {
        const toast = $('.toast');
        toast.removeClass('success error').addClass(type).text(message).addClass('show');
        setTimeout(function() {
            toast.removeClass('show');
        }, 3000);
    }

    // Initialize menu state
    function initializeMenu() {
        // 完全跳过在index.php中处理的菜单
        if (document.querySelector('.bjt-admin-sidebar')) {
            return; // 存在自定义侧边栏，跳过
        }
        
        // 原有WordPress侧边栏的初始化代码
        $('.toplevel_page_bjt-product-admin .wp-submenu > li > a').each(function() {
            var $menuItem = $(this);
            if ($menuItem.next('.wp-submenu').length) {
                $menuItem.addClass('wp-submenu-head');
                if (!$menuItem.parent().hasClass('current')) {
                    $menuItem.addClass('collapsed');
                }
            }
        });

        // Show submenu for current page
        var $currentMenu = $('.toplevel_page_bjt-product-admin .wp-submenu .current');
        if ($currentMenu.length) {
            $currentMenu.parents('.wp-submenu').addClass('expanded');
            $currentMenu.parents('.wp-submenu').prev('a').removeClass('collapsed');
        }
    }

    // Handle menu item clicks
    function handleMenuClicks() {
        // 完全跳过在index.php中处理的菜单
        if (document.querySelector('.bjt-admin-sidebar')) {
            return; // 存在自定义侧边栏，跳过
        }
        
        // 原有菜单点击处理代码
        $('.menu-item.expandable').on('click', function(e) {
            e.preventDefault();
            var $menuItem = $(this);
            var $submenu = $menuItem.next('.submenu');
            
            // Toggle this menu item
            $menuItem.toggleClass('active');
            $submenu.slideToggle(200);
            
            // Save menu state
            saveMenuState();
        });

        // Handle product line submenus
        $('.submenu .menu-item').on('click', function(e) {
            if ($(this).hasClass('has-submenu')) {
                e.preventDefault();
                var $submenu = $(this).next('.submenu');
                $submenu.slideToggle(200);
                $(this).toggleClass('active');
                saveMenuState();
            }
        });
    }

    // Save menu state
    function saveMenuState() {
        var menuState = {
            mainMenus: {},
            productLines: {},
            subMenus: {}
        };

        // Save main menu states
        $('.menu-item.expandable').each(function() {
            var id = $(this).attr('id');
            menuState.mainMenus[id] = $(this).hasClass('active');
        });

        // Save product line states
        $('.submenu .menu-item').each(function() {
            var id = $(this).attr('id');
            if (id) {
                menuState.productLines[id] = $(this).hasClass('active');
            }
        });

        // Save submenu states
        $('.submenu .submenu').each(function() {
            var id = $(this).attr('id');
            if (id) {
                menuState.subMenus[id] = $(this).is(':visible');
            }
        });

        localStorage.setItem('bjtMenuState', JSON.stringify(menuState));
    }

    // Restore menu state
    function restoreMenuState() {
        var menuState = localStorage.getItem('bjtMenuState');
        if (menuState) {
            menuState = JSON.parse(menuState);

            // Restore main menu states
            Object.keys(menuState.mainMenus).forEach(function(id) {
                var $menu = $('#' + id);
                if (menuState.mainMenus[id]) {
                    $menu.addClass('active');
                    $menu.next('.submenu').show();
                }
            });

            // Restore product line states
            Object.keys(menuState.productLines).forEach(function(id) {
                var $menu = $('#' + id);
                if (menuState.productLines[id]) {
                    $menu.addClass('active');
                }
            });

            // Restore submenu states
            Object.keys(menuState.subMenus).forEach(function(id) {
                var $submenu = $('#' + id);
                if (menuState.subMenus[id]) {
                    $submenu.show();
                }
            });
        }
    }

    // Add icons to menu items
    function addMenuIcons() {
        var icons = {
            'menu-dashboard': 'dashicons-dashboard',
            'menu-page-edit': 'dashicons-edit',
            'menu-air-cushion': 'dashicons-products',
            'menu-paper-machine': 'dashicons-media-document',
            'menu-tape-machine': 'dashicons-admin-tools',
            'menu-air-column': 'dashicons-archive',
            'menu-user-management': 'dashicons-admin-users',
            'menu-system-settings': 'dashicons-admin-settings',
            // Submenu icons
            'submenu-hosts': 'dashicons-desktop',
            'submenu-accessories': 'dashicons-admin-plugins',
            'submenu-consumables': 'dashicons-cart',
            'submenu-parts': 'dashicons-admin-tools'
        };

        // Add icons to menu items
        Object.keys(icons).forEach(function(menuClass) {
            $('.' + menuClass + ' > a').prepend(
                $('<span>').addClass('dashicons ' + icons[menuClass])
            );
        });
    }

    // Set active menu based on current page
    function setActiveMenu() {
        var currentUrl = window.location.href;
        
        // Remove all active classes first
        $('.menu-item').removeClass('active');
        $('.submenu').hide();
        
        // Find and activate the current menu item
        $('.menu-item').each(function() {
            var href = $(this).attr('href');
            if (href && currentUrl.includes(href)) {
                $(this).addClass('active');
                
                // Show parent submenus
                $(this).parents('.submenu').show();
                $(this).parents('.submenu').prev('.menu-item').addClass('active');
                
                // Show child submenu if exists
                if ($(this).hasClass('has-submenu')) {
                    $(this).next('.submenu').show();
                }
            }
        });
    }

    // Initialize everything
    function init() {
        // 检查是否存在我们的自定义侧边栏
        var hasCustomSidebar = document.querySelector('.bjt-admin-sidebar') !== null;
        
        // 只在没有自定义侧边栏时初始化菜单
        if (!hasCustomSidebar) {
            initializeMenu();
            handleMenuClicks();
            restoreMenuState();
        }
        
        // 始终初始化这些功能
        addMenuIcons();
        setActiveMenu();
        
        // ... 其他初始化代码 ...
    }

    // Run initialization
    init();
}); 