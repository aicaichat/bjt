<?php
/**
 * Plugin Name: BJT Product Management System
 * Plugin URI: https://www.bjt.com
 * Description: 集成BJT产品管理系统到WordPress后台
 * Version: 1.0.0
 * Author: BJT Team
 * Author URI: https://www.bjt.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: bjt-product-admin
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('BJT_PRODUCT_ADMIN_VERSION', '1.0.0');
define('BJT_PRODUCT_ADMIN_PATH', plugin_dir_path(__FILE__));
define('BJT_PRODUCT_ADMIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once BJT_PRODUCT_ADMIN_PATH . 'includes/admin/class-bjt-admin-pages.php';
require_once BJT_PRODUCT_ADMIN_PATH . 'includes/admin/class-bjt-product-line-management.php';
require_once BJT_PRODUCT_ADMIN_PATH . 'includes/admin/class-bjt-host-management.php';
require_once BJT_PRODUCT_ADMIN_PATH . 'includes/admin/class-bjt-part-management.php';

// Register activation hook
register_activation_hook(__FILE__, 'bjt_product_admin_activate');
function bjt_product_admin_activate() {
    // Create necessary database tables
    BJT_Product_Line_Management::get_instance()->create_tables();
    BJT_Host_Management::get_instance()->create_tables();
    BJT_Part_Management::get_instance()->create_tables();
}

// Register deactivation hook
register_deactivation_hook(__FILE__, 'bjt_product_admin_deactivate');
function bjt_product_admin_deactivate() {
    // Clean up if necessary
}

// Initialize the plugin
function bjt_product_admin_init() {
    // Load text domain
    load_plugin_textdomain(
        'bjt-product-admin',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages'
    );

    // Initialize admin pages
    BJT_Admin_Pages::get_instance();
    
    // Initialize product line management
    BJT_Product_Line_Management::get_instance();
    
    // Initialize host management
    BJT_Host_Management::get_instance();
    
    // Initialize part management
    BJT_Part_Management::get_instance();
}
add_action('plugins_loaded', 'bjt_product_admin_init');

// Register and enqueue admin scripts and styles
function bjt_product_admin_enqueue_scripts($hook) {
    // Only load on our plugin pages
    if (strpos($hook, 'bjt-product-admin') === false) {
        return;
    }

    // Register styles
    wp_register_style(
        'bjt-product-admin-style',
        BJT_PRODUCT_ADMIN_URL . 'assets/css/admin.css',
        array(),
        BJT_PRODUCT_ADMIN_VERSION
    );

    // Register scripts
    wp_register_script(
        'bjt-product-admin-script',
        BJT_PRODUCT_ADMIN_URL . 'assets/js/admin.js',
        array('jquery'),
        BJT_PRODUCT_ADMIN_VERSION,
        true
    );

    // Enqueue styles and scripts
    wp_enqueue_style('bjt-product-admin-style');
    wp_enqueue_script('bjt-product-admin-script');

    // Localize script
    wp_localize_script('bjt-product-admin-script', 'bjtAdmin', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('bjt_admin_nonce')
    ));
}
add_action('admin_enqueue_scripts', 'bjt_product_admin_enqueue_scripts');

// Register custom post types
function bjt_register_post_types() {
    // Register Product Line post type
    register_post_type('product_line', array(
        'labels' => array(
            'name'               => __('Product Lines', 'bjt-product-admin'),
            'singular_name'      => __('Product Line', 'bjt-product-admin'),
            'add_new'           => __('Add New', 'bjt-product-admin'),
            'add_new_item'      => __('Add New Product Line', 'bjt-product-admin'),
            'edit_item'         => __('Edit Product Line', 'bjt-product-admin'),
            'new_item'          => __('New Product Line', 'bjt-product-admin'),
            'view_item'         => __('View Product Line', 'bjt-product-admin'),
            'search_items'      => __('Search Product Lines', 'bjt-product-admin'),
            'not_found'         => __('No product lines found', 'bjt-product-admin'),
            'not_found_in_trash'=> __('No product lines found in Trash', 'bjt-product-admin'),
            'menu_name'         => __('Product Lines', 'bjt-product-admin')
        ),
        'public'              => true,
        'show_ui'            => true,
        'show_in_menu'       => false,
        'supports'           => array('title', 'editor', 'thumbnail'),
        'has_archive'        => true,
        'rewrite'            => array('slug' => 'product-lines'),
        'menu_icon'          => 'dashicons-products',
        'show_in_rest'       => true
    ));

    // Register Product post type
    register_post_type('product', array(
        'labels' => array(
            'name'               => __('Products', 'bjt-product-admin'),
            'singular_name'      => __('Product', 'bjt-product-admin'),
            'add_new'           => __('Add New', 'bjt-product-admin'),
            'add_new_item'      => __('Add New Product', 'bjt-product-admin'),
            'edit_item'         => __('Edit Product', 'bjt-product-admin'),
            'new_item'          => __('New Product', 'bjt-product-admin'),
            'view_item'         => __('View Product', 'bjt-product-admin'),
            'search_items'      => __('Search Products', 'bjt-product-admin'),
            'not_found'         => __('No products found', 'bjt-product-admin'),
            'not_found_in_trash'=> __('No products found in Trash', 'bjt-product-admin'),
            'menu_name'         => __('Products', 'bjt-product-admin')
        ),
        'public'              => true,
        'show_ui'            => true,
        'show_in_menu'       => false,
        'supports'           => array('title', 'editor', 'thumbnail'),
        'has_archive'        => true,
        'rewrite'            => array('slug' => 'products'),
        'menu_icon'          => 'dashicons-cart',
        'show_in_rest'       => true
    ));
}

// Register frontend template
add_filter('page_template', 'bjt_register_frontend_template');
function bjt_register_frontend_template($page_template) {
    if (is_page('products')) {
        $page_template = plugin_dir_path(__FILE__) . 'templates/frontend/product-home.php';
    }
    return $page_template;
}

// Add template to page attributes dropdown
add_filter('theme_page_templates', 'bjt_add_frontend_template');
function bjt_add_frontend_template($templates) {
    $templates['product-home.php'] = __('BJT Product Home', 'bjt-product-admin');
    return $templates;
}

// Handle language switching
add_action('wp_ajax_bjt_switch_language', 'bjt_handle_language_switch');
function bjt_handle_language_switch() {
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bjt_language_switch')) {
        wp_send_json_error('Invalid nonce');
    }

    $new_lang = sanitize_text_field($_POST['lang']);
    $lang_options = array(
        'zh_CN' => '中文',
        'en_US' => '🇬🇧 English',
        'ja'    => '🇯🇵 日本語',
        'ko_KR' => '🇰🇷 한국어',
        'fr_FR' => '🇫🇷 français',
        'de_DE' => '🇩🇪 Deutsch',
        'es_ES' => '🇪🇸 Español',
        'it_IT' => '🇮🇹 italiano',
        'ru_RU' => '🇷🇺 русский',
        'pt_PT' => '🇵🇹 português',
        'th'    => '🇹🇭 ไทย',
        'vi'    => '🇻🇳 tiếng việt'
    );

    if (in_array($new_lang, array_keys($lang_options))) {
        update_user_meta(get_current_user_id(), 'bjt_user_language', $new_lang);
        wp_send_json_success();
    } else {
        wp_send_json_error('Invalid language code');
    }
}

// Handle AJAX requests
function bjt_product_admin_ajax_handler() {
    check_ajax_referer('bjt_product_admin_nonce', 'nonce');

    $action = isset($_POST['action']) ? sanitize_text_field($_POST['action']) : '';

    switch ($action) {
        case 'save_product_line':
            $product_line_id = isset($_POST['product_line_id']) ? intval($_POST['product_line_id']) : 0;
            $title_cn = isset($_POST['title_cn']) ? sanitize_text_field($_POST['title_cn']) : '';
            $title_en = isset($_POST['title_en']) ? sanitize_text_field($_POST['title_en']) : '';
            $description_cn = isset($_POST['description_cn']) ? wp_kses_post($_POST['description_cn']) : '';
            $description_en = isset($_POST['description_en']) ? wp_kses_post($_POST['description_en']) : '';
            
            // Save product line data
            if ($product_line_id) {
                update_post_meta($product_line_id, 'title_cn', $title_cn);
                update_post_meta($product_line_id, 'title_en', $title_en);
                update_post_meta($product_line_id, 'description_cn', $description_cn);
                update_post_meta($product_line_id, 'description_en', $description_en);
                
                wp_send_json_success(array('message' => __('Product line saved successfully.', 'bjt-product-admin')));
            } else {
                wp_send_json_error(array('message' => __('Invalid product line ID.', 'bjt-product-admin')));
            }
            break;

        case 'upload_image':
            if (!function_exists('wp_handle_upload')) {
                require_once(ABSPATH . 'wp-admin/includes/file.php');
            }

            $uploadedfile = $_FILES['file'];
            $upload_overrides = array('test_form' => false);
            $movefile = wp_handle_upload($uploadedfile, $upload_overrides);

            if ($movefile && !isset($movefile['error'])) {
                wp_send_json_success(array('url' => $movefile['url']));
            } else {
                wp_send_json_error(array('message' => $movefile['error']));
            }
            break;

        default:
            wp_send_json_error(array('message' => __('Invalid action.', 'bjt-product-admin')));
    }
}
add_action('wp_ajax_bjt_product_admin', 'bjt_product_admin_ajax_handler');

// 初始化主机管理类
require_once plugin_dir_path(__FILE__) . 'includes/class-bjt-host-management.php';
add_action('plugins_loaded', function() {
    BJT_Host_Management::get_instance();
}); 