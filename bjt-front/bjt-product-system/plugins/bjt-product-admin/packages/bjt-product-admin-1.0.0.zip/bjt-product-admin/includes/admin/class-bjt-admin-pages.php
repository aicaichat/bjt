<?php
if (!defined('ABSPATH')) {
    exit;
}

class BJT_Admin_Pages {
    private static $instance = null;
    private $page_hook = null;
    private $plugin_path;
    private $plugin_url;
    private $product_lines;
    private $sections;

    private function __construct() {
        $this->plugin_path = BJT_PRODUCT_ADMIN_PATH;
        $this->plugin_url = BJT_PRODUCT_ADMIN_URL;
        
        $this->product_lines = array(
            'air-cushion' => '气垫机',
            'paper-machine' => '纸机',
            'tape-machine' => '胶带机',
            'air-column' => '气柱袋'
        );
        
        $this->sections = array(
            'hosts' => '主机',
            'accessories' => '配件',
            'consumables' => '耗材',
            'parts' => '备件'
        );

        add_action('admin_menu', array($this, 'register_admin_pages'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'bjt') === false) {
            return;
        }

        // Enqueue WordPress dashicons
        wp_enqueue_style('dashicons');

        // Enqueue admin styles
        wp_enqueue_style(
            'bjt-product-admin-style',
            BJT_PRODUCT_ADMIN_URL . 'assets/css/admin.css',
            array(),
            BJT_PRODUCT_ADMIN_VERSION
        );

        // Enqueue admin scripts
        wp_enqueue_script(
            'bjt-product-admin-script',
            BJT_PRODUCT_ADMIN_URL . 'assets/js/admin.js',
            array('jquery'),
            BJT_PRODUCT_ADMIN_VERSION,
            true
        );

        // Localize script
        wp_localize_script('bjt-product-admin-script', 'bjtAdmin', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bjt_admin_nonce')
        ));
    }

    public function render_admin_page() {
        // Include the main template
        include BJT_PRODUCT_ADMIN_PATH . 'templates/admin/main.php';
    }

    public function register_admin_pages() {
        // Add main menu
        add_menu_page(
            '产品管理系统',
            '产品管理系统',
            'manage_options',
            'bjt-product-admin',
            array($this, 'render_admin_page'),
            'dashicons-products',
            30
        );

        // Add page editing submenu
        add_submenu_page(
            'bjt-product-admin',
            '页面编辑',
            '页面编辑',
            'manage_options',
            'bjt-page-edit',
            array($this, 'render_admin_page')
        );

        // Add product line pages
        foreach ($this->product_lines as $slug => $title) {
            // Add product line main page
            add_submenu_page(
                'bjt-product-admin',
                $title,
                $title,
                'manage_options',
                'bjt-' . $slug,
                array($this, 'render_admin_page')
            );

            // Add section pages for each product line
            foreach ($this->sections as $section_slug => $section_title) {
                $page_title = $title . ' - ' . $section_title;
                $menu_title = $section_title;
                $menu_slug = 'bjt-' . $slug . '-' . $section_slug;

                add_submenu_page(
                    'bjt-product-admin',
                    $page_title,
                    $menu_title,
                    'manage_options',
                    $menu_slug,
                    array($this, 'render_admin_page')
                );

                // Add management pages for each section
                $this->add_section_management_pages($slug, $section_slug);
            }
        }

        // Add user management page
        add_submenu_page(
            'bjt-product-admin',
            '用户管理',
            '用户管理',
            'manage_options',
            'bjt-user-management',
            array($this, 'render_admin_page')
        );

        // Add system settings page
        add_submenu_page(
            'bjt-product-admin',
            '系统设置',
            '系统设置',
            'manage_options',
            'bjt-system-settings',
            array($this, 'render_admin_page')
        );
    }

    private function add_section_management_pages($product_line_slug, $section_slug) {
        $management_pages = array(
            'management' => '管理',
            'part-numbers' => '料号管理'
        );

        if ($section_slug !== 'consumables') {
            $management_pages['add'] = '新增';
        }

        if (in_array($section_slug, array('hosts', 'accessories', 'consumables'))) {
            $management_pages['add-part-number'] = '新增料号';
        }

        if ($section_slug === 'hosts') {
            $management_pages['relations'] = '关联关系';
        }

        foreach ($management_pages as $page_slug => $page_title) {
            $full_page_title = $this->product_lines[$product_line_slug] . ' - ' . 
                             $this->sections[$section_slug] . ' - ' . 
                             $page_title;
            $menu_slug = 'bjt-' . $product_line_slug . '-' . $section_slug . '-' . $page_slug;

            add_submenu_page(
                'bjt-product-admin',
                $full_page_title,
                $page_title,
                'manage_options',
                $menu_slug,
                array($this, 'render_admin_page')
            );
        }
    }

    public function get_template_path($page) {
        $template_map = array(
            'bjt-page-edit' => 'page-edit.php',
            'bjt-user-management' => 'user-management.php',
            'bjt-system-settings' => 'system-settings.php'
        );

        // Add product line templates
        foreach ($this->product_lines as $slug => $title) {
            $template_map['bjt-' . $slug] = 'product-lines/' . $slug . '/index.php';
            
            foreach ($this->sections as $section_slug => $section_title) {
                $base_path = 'product-lines/' . $slug . '/' . $section_slug . '/';
                $template_map['bjt-' . $slug . '-' . $section_slug] = $base_path . 'index.php';
                $template_map['bjt-' . $slug . '-' . $section_slug . '-management'] = $base_path . 'management.php';
                $template_map['bjt-' . $slug . '-' . $section_slug . '-part-numbers'] = $base_path . 'part-numbers.php';
                $template_map['bjt-' . $slug . '-' . $section_slug . '-add'] = $base_path . 'add.php';
                $template_map['bjt-' . $slug . '-' . $section_slug . '-add-part-number'] = $base_path . 'add-part-number.php';
                
                if ($section_slug === 'hosts') {
                    $template_map['bjt-' . $slug . '-' . $section_slug . '-relations'] = $base_path . 'relations.php';
                }
            }
        }

        if (isset($template_map[$page])) {
            $template_path = $this->plugin_path . 'templates/admin/' . $template_map[$page];
            if (file_exists($template_path)) {
                return $template_path;
            }
        }

        return false;
    }
} 