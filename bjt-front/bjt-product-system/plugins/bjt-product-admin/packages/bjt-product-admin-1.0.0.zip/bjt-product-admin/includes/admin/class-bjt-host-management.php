<?php
if (!defined('ABSPATH')) {
    exit;
}

class BJT_Host_Management {
    private static $instance = null;
    private $table_name;

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'bjt_hosts';
        
        add_action('admin_init', array($this, 'init'));
        add_action('wp_ajax_save_host', array($this, 'save_host'));
        add_action('wp_ajax_upload_host_image', array($this, 'upload_host_image'));
        add_action('wp_ajax_bjt_upload_explosion_diagram', array($this, 'handle_pdf_upload'));
        add_action('wp_ajax_bjt_get_host', array($this, 'ajax_get_host'));
        add_action('wp_ajax_bjt_save_host', array($this, 'ajax_save_host'));
        add_action('wp_ajax_bjt_delete_host', array($this, 'ajax_delete_host'));
        add_action('wp_ajax_bjt_update_host_status', array($this, 'ajax_update_host_status'));
    }

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function init() {
        // Add AJAX handlers
        add_action('wp_ajax_save_host', array($this, 'save_host'));
        add_action('wp_ajax_upload_host_image', array($this, 'upload_host_image'));
        add_action('wp_ajax_bjt_upload_explosion_diagram', array($this, 'handle_pdf_upload'));
        add_action('wp_ajax_bjt_get_host', array($this, 'ajax_get_host'));
        add_action('wp_ajax_bjt_save_host', array($this, 'ajax_save_host'));
        add_action('wp_ajax_bjt_delete_host', array($this, 'ajax_delete_host'));
        add_action('wp_ajax_bjt_update_host_status', array($this, 'ajax_update_host_status'));
    }

    public function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            model varchar(100) NOT NULL,
            title_cn varchar(255) NOT NULL,
            title_en varchar(255) NOT NULL,
            description_cn text,
            description_en text,
            specifications_cn text,
            specifications_en text,
            features_cn text,
            features_en text,
            image1_url varchar(255),
            image2_url varchar(255),
            explosion_diagram_pdf varchar(255),
            status varchar(20) DEFAULT 'publish',
            menu_order int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY model (model)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function save_host($data = array()) {
        if (empty($data)) {
            // 如果是通过AJAX直接调用，获取POST数据
            if (isset($_POST['nonce']) && wp_verify_nonce($_POST['nonce'], 'save_host')) {
                $host_id = isset($_POST['host_id']) ? intval($_POST['host_id']) : 0;
                $model = isset($_POST['model']) ? sanitize_text_field($_POST['model']) : '';
                $title_cn = isset($_POST['title_cn']) ? sanitize_text_field($_POST['title_cn']) : '';
                $title_en = isset($_POST['title_en']) ? sanitize_text_field($_POST['title_en']) : '';
                $description_cn = isset($_POST['description_cn']) ? wp_kses_post($_POST['description_cn']) : '';
                $description_en = isset($_POST['description_en']) ? wp_kses_post($_POST['description_en']) : '';
                $specifications_cn = isset($_POST['specifications_cn']) ? wp_kses_post($_POST['specifications_cn']) : '';
                $specifications_en = isset($_POST['specifications_en']) ? wp_kses_post($_POST['specifications_en']) : '';
                $features_cn = isset($_POST['features_cn']) ? wp_kses_post($_POST['features_cn']) : '';
                $features_en = isset($_POST['features_en']) ? wp_kses_post($_POST['features_en']) : '';
                $image1_url = isset($_POST['image1_url']) ? esc_url_raw($_POST['image1_url']) : '';
                $image2_url = isset($_POST['image2_url']) ? esc_url_raw($_POST['image2_url']) : '';
                $explosion_diagram_pdf = isset($_POST['explosion_diagram_pdf']) ? esc_url_raw($_POST['explosion_diagram_pdf']) : '';
                $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'publish';
                $menu_order = isset($_POST['menu_order']) ? intval($_POST['menu_order']) : 0;

                if (empty($model)) {
                    return false;
                }

                if (empty($title_cn)) {
                    $title_cn = $model;
                }

                $data = array(
                    'model' => $model,
                    'title_cn' => $title_cn,
                    'title_en' => $title_en,
                    'description_cn' => $description_cn,
                    'description_en' => $description_en,
                    'specifications_cn' => $specifications_cn,
                    'specifications_en' => $specifications_en,
                    'features_cn' => $features_cn,
                    'features_en' => $features_en,
                    'image1_url' => $image1_url,
                    'image2_url' => $image2_url,
                    'explosion_diagram_pdf' => $explosion_diagram_pdf,
                    'status' => $status,
                    'menu_order' => $menu_order
                );

                if ($host_id) {
                    $data['id'] = $host_id;
                }
            } else {
                return false;
            }
        }

        global $wpdb;

        // 提取ID（如果存在）
        $host_id = isset($data['id']) ? intval($data['id']) : 0;
        unset($data['id']);

        // 确保必要字段存在
        if (empty($data['model'])) {
            return false;
        }

        // 如果缺少标题，使用型号作为标题
        if (empty($data['title_cn'])) {
            $data['title_cn'] = $data['model'];
        }

        // 为未设置的字段填充默认值
        $defaults = array(
            'title_en' => '',
            'description_cn' => '',
            'description_en' => '',
            'specifications_cn' => '',
            'specifications_en' => '',
            'features_cn' => '',
            'features_en' => '',
            'image1_url' => '',
            'image2_url' => '',
            'explosion_diagram_pdf' => '',
            'status' => 'publish',
            'menu_order' => 0
        );

        $data = wp_parse_args($data, $defaults);

        // 执行数据库操作
        if ($host_id) {
            $result = $wpdb->update(
                $this->table_name,
                $data,
                array('id' => $host_id)
            );
            
            if ($result !== false) {
                return $host_id;
            }
        } else {
            $result = $wpdb->insert(
                $this->table_name,
                $data
            );
            
            if ($result) {
                return $wpdb->insert_id;
            }
        }

        return false;
    }

    public function upload_host_image() {
        check_ajax_referer('upload_host_image', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        if (!function_exists('wp_handle_upload')) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
        }

        $uploadedfile = $_FILES['file'];
        $upload_overrides = array('test_form' => false);
        $movefile = wp_handle_upload($uploadedfile, $upload_overrides);

        if ($movefile && !isset($movefile['error'])) {
            wp_send_json_success(array(
                'url' => $movefile['url'],
                'file' => $movefile['file']
            ));
        } else {
            wp_send_json_error($movefile['error']);
        }
    }

    /**
     * 获取单个主机
     */
    public function get_host($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $id
        ));
    }

    /**
     * 获取所有主机
     */
    public function get_all_hosts() {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT * FROM {$this->table_name} ORDER BY created_at DESC"
        );
    }

    /**
     * 更新主机状态
     */
    public function update_host_status($id, $status) {
        global $wpdb;
        return $wpdb->update(
            $this->table_name,
            array('status' => $status),
            array('id' => $id)
        );
    }

    /**
     * 删除主机
     */
    public function delete_host($id) {
        global $wpdb;
        return $wpdb->delete(
            $this->table_name,
            array('id' => $id)
        );
    }

    public function handle_pdf_upload() {
        check_ajax_referer('bjt_upload_explosion_diagram', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '权限不足'));
        }

        if (empty($_FILES['pdf_file'])) {
            wp_send_json_error(array('message' => '未选择文件'));
        }

        $file = $_FILES['pdf_file'];
        
        // 验证文件类型
        $file_type = wp_check_filetype($file['name']);
        if ($file_type['ext'] !== 'pdf') {
            wp_send_json_error(array('message' => '只允许上传PDF文件'));
        }

        // 验证文件大小（最大10MB）
        if ($file['size'] > 10 * 1024 * 1024) {
            wp_send_json_error(array('message' => '文件大小不能超过10MB'));
        }

        // 创建上传目录
        $upload_dir = wp_upload_dir();
        $explosion_dir = $upload_dir['basedir'] . '/bjt-explosion-diagrams';
        if (!file_exists($explosion_dir)) {
            wp_mkdir_p($explosion_dir);
        }

        // 生成唯一文件名
        $random_string = substr(md5(uniqid(mt_rand(), true)), 0, 8);
        $file_name = 'explosion_diagram_' . time() . '_' . $random_string . '.pdf';
        $file_path = $explosion_dir . '/' . $file_name;

        // 移动文件
        if (!move_uploaded_file($file['tmp_name'], $file_path)) {
            wp_send_json_error(array('message' => '文件上传失败'));
        }

        // 返回文件URL
        $file_url = $upload_dir['baseurl'] . '/bjt-explosion-diagrams/' . $file_name;
        wp_send_json_success(array('url' => $file_url));
    }

    /**
     * AJAX: 获取主机
     */
    public function ajax_get_host() {
        check_ajax_referer('bjt_get_host', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '权限不足'));
        }
        
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if (!$id) {
            wp_send_json_error(array('message' => '无效的ID'));
        }
        
        $host = $this->get_host($id);
        if (!$host) {
            wp_send_json_error(array('message' => '主机不存在'));
        }
        
        wp_send_json_success($host);
    }

    /**
     * AJAX: 保存主机
     */
    public function ajax_save_host() {
        check_ajax_referer('bjt_save_host', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '权限不足'));
        }
        
        // 检查必要字段
        if (!isset($_POST['model'])) {
            wp_send_json_error(array('message' => '缺少模型名称'));
        }
        
        $data = array(
            'model' => sanitize_text_field($_POST['model']),
            'status' => isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'publish'
        );
        
        // 可选字段：PDF文件URL
        if (isset($_POST['explosion_diagram_pdf'])) {
            $data['explosion_diagram_pdf'] = esc_url_raw($_POST['explosion_diagram_pdf']);
        }
        
        // 如果是编辑模式，获取ID
        if (isset($_POST['id'])) {
            $data['id'] = intval($_POST['id']);
        }
        
        // 对应简化版本的录入，暂时添加空值
        if (!isset($data['title_cn'])) {
            $data['title_cn'] = $data['model'];
        }
        if (!isset($data['title_en'])) {
            $data['title_en'] = '';
        }
        
        $id = $this->save_host($data);
        if ($id) {
            wp_send_json_success(array('id' => $id));
        } else {
            wp_send_json_error(array('message' => '保存失败'));
        }
    }

    /**
     * AJAX: 删除主机
     */
    public function ajax_delete_host() {
        check_ajax_referer('bjt_delete_host', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '权限不足'));
        }
        
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if (!$id) {
            wp_send_json_error(array('message' => '无效的ID'));
        }
        
        if ($this->delete_host($id)) {
            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => '删除失败'));
        }
    }

    /**
     * AJAX: 更新主机状态
     */
    public function ajax_update_host_status() {
        check_ajax_referer('bjt_update_host_status', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => '权限不足'));
        }
        
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';
        
        if (!$id || !$status) {
            wp_send_json_error(array('message' => '无效的参数'));
        }
        
        if ($this->update_host_status($id, $status)) {
            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => '更新失败'));
        }
    }
} 