<?php
if (!defined('ABSPATH')) {
    exit;
}

$host_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$host = get_post($host_id);
$title_cn = get_post_meta($host_id, 'title_cn', true);
$title_en = get_post_meta($host_id, 'title_en', true);
$description = get_post_meta($host_id, 'description', true);
$specifications = get_post_meta($host_id, 'specifications', true);
$features = get_post_meta($host_id, 'features', true);
$applications = get_post_meta($host_id, 'applications', true);
$message = isset($_GET['message']) ? $_GET['message'] : '';
?>

<div class="wrap bjt-host-edit">
    <h1 class="wp-heading-inline">编辑主机</h1>
    <a href="<?php echo admin_url('admin.php?page=bjt-product-admin&action=list-hosts&product_line=' . $host->post_parent); ?>" class="page-title-action">返回列表</a>
    
    <?php if ($message === 'saved'): ?>
    <div class="notice notice-success is-dismissible">
        <p>主机已保存。</p>
    </div>
    <?php endif; ?>
    
    <form id="hostForm" method="post" action="">
        <?php wp_nonce_field('save_host', 'host_nonce'); ?>
        <input type="hidden" name="action" value="save_host">
        <input type="hidden" name="host_id" value="<?php echo $host_id; ?>">
        
        <div class="section">
            <div class="section-header">
                <h3 class="section-title">基本信息</h3>
            </div>
            <div class="form-group">
                <label class="form-label">中文名称：</label>
                <input type="text" class="form-control" name="title_cn" value="<?php echo esc_attr($title_cn); ?>" required>
            </div>
            <div class="form-group">
                <label class="form-label">英文名称：</label>
                <input type="text" class="form-control" name="title_en" value="<?php echo esc_attr($title_en); ?>">
            </div>
            <div class="form-group">
                <label class="form-label">状态：</label>
                <select class="form-control" name="status">
                    <option value="publish" <?php selected($host->post_status, 'publish'); ?>>上架</option>
                    <option value="draft" <?php selected($host->post_status, 'draft'); ?>>下架</option>
                </select>
            </div>
        </div>
        
        <div class="section">
            <div class="section-header">
                <h3 class="section-title">产品描述</h3>
            </div>
            <div class="form-group">
                <label class="form-label">描述：</label>
                <?php
                wp_editor($description, 'description', array(
                    'media_buttons' => true,
                    'textarea_name' => 'description',
                    'textarea_rows' => 10,
                    'teeny' => false,
                    'quicktags' => true
                ));
                ?>
            </div>
        </div>
        
        <div class="section">
            <div class="section-header">
                <h3 class="section-title">规格参数</h3>
            </div>
            <div class="form-group">
                <label class="form-label">规格：</label>
                <?php
                wp_editor($specifications, 'specifications', array(
                    'media_buttons' => true,
                    'textarea_name' => 'specifications',
                    'textarea_rows' => 10,
                    'teeny' => false,
                    'quicktags' => true
                ));
                ?>
            </div>
        </div>
        
        <div class="section">
            <div class="section-header">
                <h3 class="section-title">产品特点</h3>
            </div>
            <div class="form-group">
                <label class="form-label">特点：</label>
                <?php
                wp_editor($features, 'features', array(
                    'media_buttons' => true,
                    'textarea_name' => 'features',
                    'textarea_rows' => 10,
                    'teeny' => false,
                    'quicktags' => true
                ));
                ?>
            </div>
        </div>
        
        <div class="section">
            <div class="section-header">
                <h3 class="section-title">应用领域</h3>
            </div>
            <div class="form-group">
                <label class="form-label">应用：</label>
                <?php
                wp_editor($applications, 'applications', array(
                    'media_buttons' => true,
                    'textarea_name' => 'applications',
                    'textarea_rows' => 10,
                    'teeny' => false,
                    'quicktags' => true
                ));
                ?>
            </div>
        </div>
        
        <div class="submit-section">
            <button type="submit" class="btn btn-primary">保存</button>
            <a href="<?php echo admin_url('admin.php?page=bjt-product-admin&action=list-hosts&product_line=' . $host->post_parent); ?>" class="btn" style="background-color: #6c757d;">取消</a>
        </div>
    </form>
</div>

<style>
.bjt-host-edit {
    margin: 20px 0;
}

.section {
    background-color: #fff;
    border-radius: 6px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
    padding: 20px;
    margin-bottom: 30px;
}

.section-header {
    margin-bottom: 20px;
}

.section-title {
    font-size: 18px;
    font-weight: 600;
    color: #1a3c70;
    margin: 0;
}

.form-group {
    margin-bottom: 20px;
}

.form-label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
    color: #495057;
    font-size: 14px;
}

.form-control {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 14px;
}

.form-control:focus {
    outline: none;
    border-color: #4dabf7;
    box-shadow: 0 0 0 3px rgba(77, 171, 247, 0.2);
}

.submit-section {
    margin-top: 30px;
    display: flex;
    gap: 10px;
}

.btn {
    padding: 8px 16px;
    background-color: #1a3c70;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-weight: 500;
    font-size: 14px;
    transition: background-color 0.2s;
    text-decoration: none;
}

.btn:hover {
    background-color: #15305b;
}

.btn-primary {
    background-color: #1a3c70;
}

@media screen and (max-width: 782px) {
    .submit-section {
        flex-direction: column;
    }
    
    .btn {
        width: 100%;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    $('#hostForm').on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        formData.append('action', 'save_host');
        formData.append('nonce', '<?php echo wp_create_nonce('save_host'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    window.location.href = '<?php echo admin_url('admin.php?page=bjt-product-admin&action=list-hosts&product_line=' . $host->post_parent . '&message=saved'); ?>';
                } else {
                    alert('保存失败：' + response.data);
                }
            },
            error: function() {
                alert('保存失败，请重试。');
            }
        });
    });
});
</script> 