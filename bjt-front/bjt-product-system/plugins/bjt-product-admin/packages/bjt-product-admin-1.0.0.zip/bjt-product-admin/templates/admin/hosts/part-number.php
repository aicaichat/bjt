<?php
if (!defined('ABSPATH')) {
    exit;
}

// 获取所有主机料号
$hosts = BJT_Host_Part_Number_Management::get_instance()->get_all_hosts();
?>

<div class="bjt-admin-content-header">
    <h2>主机料号管理</h2>
    <div class="bjt-admin-actions">
        <button class="btn btn-primary" id="addHostBtn">
            <span class="dashicons dashicons-plus"></span> 新增料号
        </button>
    </div>
</div>

<div class="bjt-admin-filters">
    <div class="filter-group">
        <label class="filter-label">搜索：</label>
        <input type="text" class="filter-input" id="hostSearch" placeholder="请输入型号、料号或名称">
    </div>
    <div class="filter-group">
        <label class="filter-label">状态：</label>
        <select class="filter-input" id="statusFilter">
            <option value="">全部</option>
            <option value="publish">已发布</option>
            <option value="draft">草稿</option>
        </select>
    </div>
    <button class="btn btn-primary" id="filterBtn">筛选</button>
    <button class="btn" style="background-color: #6c757d;" id="resetFilterBtn">重置</button>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th style="width: 80px;">No</th>
                <th>型号</th>
                <th>料号</th>
                <th>中文名称</th>
                <th>英文名称</th>
                <th>电压</th>
                <th>规格说明</th>
                <th style="width: 180px;">状态</th>
                <th style="width: 200px;">创建时间</th>
                <th style="width: 200px;">操作</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($hosts as $index => $host): ?>
            <tr>
                <td><?php echo $index + 1; ?></td>
                <td><?php echo esc_html($host->model); ?></td>
                <td><?php echo esc_html($host->part_number); ?></td>
                <td><?php echo esc_html($host->name_cn); ?></td>
                <td><?php echo esc_html($host->name_en); ?></td>
                <td><?php echo esc_html($host->voltage); ?></td>
                <td>
                    <?php if (!empty($host->specification_pdf)): ?>
                        <a href="<?php echo esc_url($host->specification_pdf); ?>" target="_blank" class="btn btn-sm btn-info">
                            <span class="dashicons dashicons-media-document"></span> 查看
                        </a>
                    <?php else: ?>
                        <span class="bjt-no-pdf">未上传</span>
                    <?php endif; ?>
                </td>
                <td>
                    <span class="status-icon <?php echo $host->status === 'publish' ? 'status-active' : 'status-inactive'; ?>"></span>
                    <?php echo $host->status === 'publish' ? '已发布' : '草稿'; ?>
                </td>
                <td><?php echo date('Y-m-d H:i', strtotime($host->created_at)); ?></td>
                <td class="action-buttons">
                    <button class="btn btn-sm btn-primary edit-host" data-id="<?php echo $host->id; ?>">
                        <span class="dashicons dashicons-edit"></span> 编辑
                    </button>
                    <button class="btn btn-sm btn-info upload-pdf" data-id="<?php echo $host->id; ?>">
                        <span class="dashicons dashicons-upload"></span> 规格说明
                    </button>
                    <button class="btn btn-sm btn-danger delete-host" data-id="<?php echo $host->id; ?>">
                        <span class="dashicons dashicons-trash"></span> 删除
                    </button>
                    <button class="btn btn-sm <?php echo $host->status === 'publish' ? 'btn-warning' : 'btn-success'; ?> toggle-status" 
                            data-id="<?php echo $host->id; ?>" 
                            data-status="<?php echo $host->status; ?>">
                        <span class="dashicons <?php echo $host->status === 'publish' ? 'dashicons-hidden' : 'dashicons-visibility'; ?>"></span>
                        <?php echo $host->status === 'publish' ? '下架' : '上架'; ?>
                    </button>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- 主机料号编辑模态框 -->
<div class="modal" id="hostModal">
    <div class="modal-dialog">
        <div class="modal-header">
            <h4 class="modal-title" id="hostModalTitle">新增料号</h4>
            <button class="modal-close" id="closeHostModal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="hostForm">
                <input type="hidden" id="hostId" name="host_id">
                <div class="form-section">
                    <h3>基本信息</h3>
                    <div class="form-group">
                        <label class="form-label">料号：</label>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <input type="text" class="form-control" id="partNumber" name="part_number" required>
                            <button type="button" class="btn btn-primary" id="fetchFromCRM">从CRM获取</button>
                        </div>
                        <span class="hint">*唯一，不能重复</span>
                    </div>
                    <div class="form-group">
                        <label class="form-label">型号：</label>
                        <input type="text" class="form-control" id="model" name="model" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">电压：</label>
                        <input type="text" class="form-control" id="voltage" name="voltage">
                    </div>
                    <div class="form-group">
                        <label class="form-label">中文名称：</label>
                        <input type="text" class="form-control" id="nameCn" name="name_cn" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">英文名称：</label>
                        <input type="text" class="form-control" id="nameEn" name="name_en">
                    </div>
                    <div class="form-group">
                        <label class="form-label">品牌：</label>
                        <input type="text" class="form-control" id="brand" name="brand">
                    </div>
                </div>

                <div class="form-section">
                    <h3>包装信息</h3>
                    <div class="form-group">
                        <label class="form-label">包装长度 (mm)：</label>
                        <input type="number" class="form-control" id="packageLength" name="package_length">
                    </div>
                    <div class="form-group">
                        <label class="form-label">包装宽度 (mm)：</label>
                        <input type="number" class="form-control" id="packageWidth" name="package_width">
                    </div>
                    <div class="form-group">
                        <label class="form-label">包装高度 (mm)：</label>
                        <input type="number" class="form-control" id="packageHeight" name="package_height">
                    </div>
                    <div class="form-group">
                        <label class="form-label">包装毛重 (kg)：</label>
                        <input type="number" class="form-control" id="packageWeight" name="package_weight" step="0.01">
                    </div>
                </div>

                <div class="form-section">
                    <h3>托盘信息</h3>
                    <div class="form-group">
                        <label class="form-label">托盘长度 (mm)：</label>
                        <input type="number" class="form-control" id="palletLength" name="pallet_length">
                    </div>
                    <div class="form-group">
                        <label class="form-label">托盘宽度 (mm)：</label>
                        <input type="number" class="form-control" id="palletWidth" name="pallet_width">
                    </div>
                    <div class="form-group">
                        <label class="form-label">托盘高度 (mm)：</label>
                        <input type="number" class="form-control" id="palletHeight" name="pallet_height">
                    </div>
                    <div class="form-group">
                        <label class="form-label">一托数量：</label>
                        <input type="number" class="form-control" id="quantityPerPallet" name="quantity_per_pallet">
                    </div>
                    <div class="form-group">
                        <label class="form-label">打托后总高度 (mm)：</label>
                        <input type="number" class="form-control" id="totalHeight" name="total_height">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">状态：</label>
                    <select class="form-control" id="status" name="status">
                        <option value="publish">已发布</option>
                        <option value="draft">草稿</option>
                    </select>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn" style="background-color: #6c757d;" id="cancelHostBtn">取消</button>
            <button class="btn btn-primary" id="saveHostBtn">保存</button>
        </div>
    </div>
</div>

<!-- PDF上传模态框 -->
<div class="modal" id="pdfModal">
    <div class="modal-dialog">
        <div class="modal-header">
            <h4 class="modal-title">上传规格说明PDF</h4>
            <button class="modal-close" id="closePdfModal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="pdfForm" enctype="multipart/form-data">
                <input type="hidden" id="pdfHostId" name="host_id">
                <div class="bjt-upload-area" id="pdfDropArea">
                    <p>将PDF文件拖放至此处，或</p>
                    <input type="file" id="pdfFile" name="pdf_file" accept=".pdf" style="display: none;">
                    <button type="button" class="btn" id="selectPdfBtn">选择文件</button>
                </div>
                <div class="bjt-upload-progress" style="display: none;">
                    <div class="bjt-progress-bar"></div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button class="btn" style="background-color: #6c757d;" id="cancelPdfBtn">取消</button>
            <button class="btn btn-primary" id="uploadPdfBtn">上传</button>
        </div>
    </div>
</div>

<!-- 确认模态框 -->
<div class="modal" id="confirmModal">
    <div class="modal-dialog">
        <div class="modal-header">
            <h4 class="modal-title" id="confirmModalTitle">确认操作</h4>
            <button class="modal-close" id="closeConfirmModal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="alert alert-warning">
                <p id="confirmMessage">您确定要执行此操作吗？此操作无法撤销。</p>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn" style="background-color: #6c757d;" id="cancelConfirmBtn">取消</button>
            <button class="btn btn-danger" id="confirmActionBtn">确认</button>
        </div>
    </div>
</div>

<!-- Toast通知 -->
<div class="toast" id="toast">
    <span id="toastMessage">操作成功</span>
</div>

<style>
/* 复用4.html中的样式 */
<?php include(plugin_dir_path(__FILE__) . '../../../assets/css/admin.css'); ?>

.form-section {
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid #e1e5eb;
}

.form-section h3 {
    font-size: 16px;
    color: #1a3c70;
    margin-bottom: 15px;
}

.hint {
    display: block;
    font-size: 12px;
    color: #6c757d;
    margin-top: 5px;
}
</style>

<script>
jQuery(document).ready(function($) {
    // 复用4.html中的JavaScript代码
    <?php include(plugin_dir_path(__FILE__) . '../../../assets/js/host-part-number.js'); ?>

    // CRM API集成
    $('#fetchFromCRM').click(function() {
        const partNumber = $('#partNumber').val().trim();
        
        if (!partNumber) {
            showToast('请输入料号', 'error');
            return;
        }

        // 显示加载状态
        $(this).prop('disabled', true).text('获取中...');
        
        // 模拟API调用
        setTimeout(function() {
            // 模拟返回数据
            const mockData = {
                model: 'Z4BLD-' + partNumber.slice(-2),
                voltage: '220V',
                name: '标准备件-' + partNumber,
                brand: 'BJT',
                packageInfo: {
                    length: 300,
                    width: 200,
                    height: 150,
                    weight: 2.5
                },
                palletInfo: {
                    length: 1200,
                    width: 800,
                    height: 150,
                    quantity: 20,
                    totalHeight: 1200
                }
            };

            // 填充表单
            $('#model').val(mockData.model);
            $('#voltage').val(mockData.voltage);
            $('#nameCn').val(mockData.name);
            $('#brand').val(mockData.brand);
            $('#packageLength').val(mockData.packageInfo.length);
            $('#packageWidth').val(mockData.packageInfo.width);
            $('#packageHeight').val(mockData.packageInfo.height);
            $('#packageWeight').val(mockData.packageInfo.weight);
            $('#palletLength').val(mockData.palletInfo.length);
            $('#palletWidth').val(mockData.palletInfo.width);
            $('#palletHeight').val(mockData.palletInfo.height);
            $('#quantityPerPallet').val(mockData.palletInfo.quantity);
            $('#totalHeight').val(mockData.palletInfo.totalHeight);

            // 重置按钮状态
            $('#fetchFromCRM').prop('disabled', false).text('从CRM获取');
            showToast('数据获取成功', 'success');
        }, 1500);
    });
});
</script> 