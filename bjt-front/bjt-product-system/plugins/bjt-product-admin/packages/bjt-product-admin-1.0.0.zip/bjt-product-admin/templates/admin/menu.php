<?php
if (!defined('ABSPATH')) {
    exit;
}

$current_page = $_GET['page'];
$product_lines = array(
    'air-cushion' => array(
        'title' => '气垫机',
        'icon' => '🛋️'
    ),
    'paper-machine' => array(
        'title' => '纸机',
        'icon' => '📃'
    ),
    'tape-machine' => array(
        'title' => '胶带机',
        'icon' => '🧵'
    ),
    'air-column' => array(
        'title' => '气柱袋',
        'icon' => '💼'
    )
);

$sections = array(
    'hosts' => array(
        'title' => '主机',
        'items' => array(
            'management' => '主机管理',
            'part-numbers' => '料号管理',
            'add' => '新增主机',
            'add-part-number' => '新增料号',
            'relations' => '关联关系'
        )
    ),
    'accessories' => array(
        'title' => '配件',
        'items' => array(
            'management' => '配件管理',
            'part-numbers' => '配件料号管理',
            'add' => '新增配件',
            'add-part-number' => '新增料号'
        )
    ),
    'consumables' => array(
        'title' => '耗材',
        'items' => array(
            'management' => '耗材管理',
            'part-numbers' => '耗材料号管理',
            'add-part-number' => '新增料号'
        )
    ),
    'parts' => array(
        'title' => '备件',
        'items' => array(
            'management' => '备件管理',
            'part-numbers' => '备件料号管理',
            'add' => '新增备件'
        )
    )
);
?>

<div class="sidebar">
    <a href="?page=bjt-product-admin" class="menu-item <?php echo $current_page === 'bjt-product-admin' ? 'active' : ''; ?>">
        <span class="menu-icon">🏠</span>
        <span>首页</span>
    </a>
    
    <a href="?page=bjt-page-edit" class="menu-item expandable <?php echo strpos($current_page, 'bjt-page-edit') !== false ? 'active' : ''; ?>">
        <span class="menu-icon">📄</span>
        <span>页面编辑</span>
    </a>
    <div class="submenu <?php echo strpos($current_page, 'bjt-page-edit') !== false ? 'active' : ''; ?>">
        <?php for ($i = 1; $i <= 4; $i++) : ?>
            <a href="?page=bjt-page-edit&line=<?php echo $i; ?>" class="menu-item <?php echo isset($_GET['line']) && $_GET['line'] == $i ? 'active' : ''; ?>">
                产品线<?php echo $i; ?>
            </a>
        <?php endfor; ?>
    </div>
    
    <?php foreach ($product_lines as $slug => $line) : ?>
        <a href="?page=bjt-<?php echo $slug; ?>" class="menu-item expandable <?php echo strpos($current_page, 'bjt-' . $slug) !== false ? 'active' : ''; ?>">
            <span class="menu-icon"><?php echo $line['icon']; ?></span>
            <span><?php echo $line['title']; ?></span>
        </a>
        <div class="submenu <?php echo strpos($current_page, 'bjt-' . $slug) !== false ? 'active' : ''; ?>">
            <?php foreach ($sections as $section_slug => $section) : ?>
                <a href="?page=bjt-<?php echo $slug . '-' . $section_slug; ?>" class="menu-item has-submenu <?php echo strpos($current_page, 'bjt-' . $slug . '-' . $section_slug) !== false ? 'active' : ''; ?>">
                    <?php echo $section['title']; ?>
                </a>
                <div class="submenu <?php echo strpos($current_page, 'bjt-' . $slug . '-' . $section_slug) !== false ? 'active' : ''; ?>">
                    <?php foreach ($section['items'] as $item_slug => $item_title) : ?>
                        <a href="?page=bjt-<?php echo $slug . '-' . $section_slug . '-' . $item_slug; ?>" class="menu-item <?php echo $current_page === 'bjt-' . $slug . '-' . $section_slug . '-' . $item_slug ? 'active' : ''; ?>">
                            <?php echo $item_title; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>
    
    <a href="?page=bjt-user-management" class="menu-item <?php echo $current_page === 'bjt-user-management' ? 'active' : ''; ?>">
        <span class="menu-icon">👤</span>
        <span>用户管理</span>
    </a>
    
    <a href="?page=bjt-system-settings" class="menu-item <?php echo $current_page === 'bjt-system-settings' ? 'active' : ''; ?>">
        <span class="menu-icon">⚙️</span>
        <span>系统设置</span>
    </a>
</div> 