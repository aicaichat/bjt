<?php
/**
 * Template Name: BJT Product Home
 * Description: Frontend product display page for BJT Product Management System
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get current language
$current_lang = get_locale();
$is_english = strpos($current_lang, 'en') === 0;

// Get product lines from the database using BJT_Product_Line_Management
$product_line_manager = BJT_Product_Line_Management::get_instance();
$product_lines = $product_line_manager->get_all_product_lines();

// 获取当前语言对应的字段后缀
$lang_suffix = $is_english ? 'en' : 'cn';
?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr($current_lang); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html__('BJT Product Management System', 'bjt-product-admin'); ?></title>
    <style>
        /* General Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f7f9fb;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Header Styles */
        header {
            background-color: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            position: sticky;
            top: 0;
            z-index: 100;
            padding: 0;
        }
        
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 20px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .logo img {
            height: 42px;
            display: block;
        }
        
        .navigation {
            display: flex;
            align-items: center;
            margin-left: 40px;
            flex-grow: 1;
        }
        
        .nav-menu {
            list-style: none;
            display: flex;
            gap: 28px;
        }
        
        .nav-link {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            font-size: 15px;
            padding: 6px 0;
            position: relative;
            transition: color 0.2s;
        }
        
        .nav-link:hover {
            color: #1A365D;
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: #1A365D;
            transition: width 0.2s;
        }
        
        .nav-link:hover::after {
            width: 100%;
        }
        
        .header-right {
            display: flex;
            align-items: center;
        }
        
        .language-select {
            margin-right: 18px;
            padding: 7px 12px;
            border: 1px solid #eaeaea;
            border-radius: 4px;
            background-color: white;
            cursor: pointer;
            font-size: 14px;
            color: #555;
        }
        
        .language-select:focus {
            outline: none;
            border-color: #1A365D;
        }
        
        .language-select option {
            padding: 8px;
            font-size: 14px;
        }
        
        .login-btn {
            background-color: #1A365D;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 9px 16px;
            cursor: pointer;
            font-weight: 500;
            font-size: 14px;
            letter-spacing: 0.3px;
            transition: background-color 0.2s;
        }
        
        .login-btn:hover {
            background-color: #274785;
        }
        
        /* Main Content Styles */
        main {
            padding: 30px 0;
        }
        
        .product-section {
            background-color: white;
            border-radius: 6px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            overflow: hidden;
        }
        
        .section-header {
            background-color: #1A365D;
            color: white;
            padding: 15px 20px;
            font-size: 24px;
            font-weight: 500;
        }
        
        .section-content {
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
        }
        
        .section-text {
            flex: 1;
            min-width: 300px;
            color: #555;
            line-height: 1.6;
            padding-right: 20px;
        }
        
        .section-image {
            flex: 0 0 auto;
            max-width: 300px;
        }
        
        .section-image img {
            max-width: 100%;
            height: auto;
            border-radius: 4px;
        }
        
        .product-links {
            margin-top: 20px;
        }
        
        .product-link {
            display: block;
            color: #0066cc;
            text-decoration: none;
            margin-bottom: 10px;
            font-weight: 500;
        }
        
        .product-link::after {
            content: "⚡";
            margin-left: 8px;
            font-size: 0.8em;
        }
        
        .product-link:hover {
            text-decoration: underline;
        }
        
        /* Divider */
        .divider {
            height: 1px;
            background-color: #eee;
            margin: 15px 0;
        }
        
        /* Responsive Styles */
        @media (max-width: 768px) {
            .section-content {
                flex-direction: column;
            }
            
            .section-text {
                padding-right: 0;
                margin-bottom: 20px;
            }
            
            .section-image {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="<?php echo esc_url(plugins_url('assets/images/logo-1.webp', dirname(dirname(__FILE__)))); ?>" alt="BJT Logo">
            </div>
            <div class="navigation">
                <nav>
                    <ul class="nav-menu">
                        <li><a href="<?php echo esc_url(home_url()); ?>" class="nav-link"><?php echo esc_html__('Home', 'bjt-product-admin'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/products')); ?>" class="nav-link"><?php echo esc_html__('Products', 'bjt-product-admin'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/documentation')); ?>" class="nav-link"><?php echo esc_html__('Documentation', 'bjt-product-admin'); ?></a></li>
                        <li><a href="<?php echo esc_url(home_url('/support')); ?>" class="nav-link"><?php echo esc_html__('Support', 'bjt-product-admin'); ?></a></li>
                    </ul>
                </nav>
            </div>
            <div class="header-right">
                <select class="language-select" id="language-selector">
                    <option value="zh_CN" <?php selected($current_lang, 'zh_CN'); ?>>中文</option>
                    <option value="en_US" <?php selected($current_lang, 'en_US'); ?>>🇬🇧 English</option>
                    <option value="ja" <?php selected($current_lang, 'ja'); ?>>🇯🇵 日本語</option>
                    <option value="ko_KR" <?php selected($current_lang, 'ko_KR'); ?>>🇰🇷 한국어</option>
                    <option value="fr_FR" <?php selected($current_lang, 'fr_FR'); ?>>🇫🇷 français</option>
                    <option value="de_DE" <?php selected($current_lang, 'de_DE'); ?>>🇩🇪 Deutsch</option>
                    <option value="es_ES" <?php selected($current_lang, 'es_ES'); ?>>🇪🇸 Español</option>
                    <option value="it_IT" <?php selected($current_lang, 'it_IT'); ?>>🇮🇹 italiano</option>
                    <option value="ru_RU" <?php selected($current_lang, 'ru_RU'); ?>>🇷🇺 русский</option>
                    <option value="pt_PT" <?php selected($current_lang, 'pt_PT'); ?>>🇵🇹 português</option>
                    <option value="th" <?php selected($current_lang, 'th'); ?>>🇹🇭 ไทย</option>
                    <option value="vi" <?php selected($current_lang, 'vi'); ?>>🇻🇳 tiếng việt</option>
                </select>
                <?php if (!is_user_logged_in()): ?>
                    <button class="login-btn"><?php echo esc_html__('Login', 'bjt-product-admin'); ?></button>
                <?php else: ?>
                    <a href="<?php echo esc_url(admin_url()); ?>" class="login-btn"><?php echo esc_html__('Dashboard', 'bjt-product-admin'); ?></a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    
    <main class="container">
        <?php if (!empty($product_lines)): ?>
            <?php foreach ($product_lines as $product_line): ?>
                <div class="product-section">
                    <div class="section-header">
                        <?php echo esc_html($product_line['title_'.$lang_suffix]); ?>
                    </div>
                    <div class="section-content">
                        <div class="section-text">
                            <p class="introduction"><?php echo esc_html__('Introduction', 'bjt-product-admin'); ?></p>
                            <div class="divider"></div>
                            <p><?php echo esc_html($product_line['description_'.$lang_suffix]); ?></p>
                            
                            <div class="product-links">
                                <?php if (!empty($product_line['subitem1_'.$lang_suffix])): ?>
                                    <a href="#" class="product-link"><?php echo esc_html($product_line['subitem1_'.$lang_suffix]); ?></a>
                                <?php endif; ?>
                                <?php if (!empty($product_line['subitem2_'.$lang_suffix])): ?>
                                    <a href="#" class="product-link"><?php echo esc_html($product_line['subitem2_'.$lang_suffix]); ?></a>
                                <?php endif; ?>
                                <?php if (!empty($product_line['subitem3_'.$lang_suffix])): ?>
                                    <a href="#" class="product-link"><?php echo esc_html($product_line['subitem3_'.$lang_suffix]); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="section-image">
                            <?php
                            $image_url = !empty($product_line['image_url']) 
                                ? $product_line['image_url'] 
                                : plugins_url('assets/images/placeholder.png', dirname(dirname(__FILE__)));
                            ?>
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($product_line['title_'.$lang_suffix]); ?>">
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="product-section">
                <div class="section-header">
                    <?php echo esc_html__('No product lines available', 'bjt-product-admin'); ?>
                </div>
                <div class="section-content">
                    <p><?php echo esc_html__('No product lines have been added yet.', 'bjt-product-admin'); ?></p>
                </div>
            </div>
        <?php endif; ?>
    </main>
    
    <script>
        // Display login alert when clicking on product links
        document.querySelectorAll('.product-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                alert('Please login to access this content.');
            });
        });
        
        // Redirect to login page when clicking login button
        document.querySelector('.login-btn').addEventListener('click', function() {
            // In a real application, redirect to the login page
            window.location.href = '<?php echo esc_url(wp_login_url()); ?>';
        });
        
        // Language selector functionality
        document.getElementById('language-selector').addEventListener('change', function() {
            const selectedLang = this.value;
            
            // Create a form to submit the language change
            const form = document.createElement('form');
            form.method = 'post';
            form.action = '<?php echo esc_url(admin_url('admin-ajax.php')); ?>';
            
            const actionInput = document.createElement('input');
            actionInput.type = 'hidden';
            actionInput.name = 'action';
            actionInput.value = 'bjt_switch_language';
            
            const langInput = document.createElement('input');
            langInput.type = 'hidden';
            langInput.name = 'lang';
            langInput.value = selectedLang;
            
            const nonceInput = document.createElement('input');
            nonceInput.type = 'hidden';
            nonceInput.name = 'nonce';
            nonceInput.value = '<?php echo wp_create_nonce('bjt_language_switch'); ?>';
            
            form.appendChild(actionInput);
            form.appendChild(langInput);
            form.appendChild(nonceInput);
            
            document.body.appendChild(form);
            form.submit();
        });
    </script>
</body>
</html> 